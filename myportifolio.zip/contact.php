<?php
// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

// Load Composer's autoloader
// require 'vendor/autoload.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate form inputs
    $name = htmlspecialchars(trim($_POST['name']));
    $mobile = htmlspecialchars(trim($_POST['mobile']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));

    $errors = [];

    // Validate name
    if (empty($name)) {
        $errors[] = "Name is required.";
    }

    // Validate mobile number
    if (empty($mobile) || !preg_match('/^[6-9]\d{9}$/', $mobile)) {
        $errors[] = "Enter a valid 10-digit mobile number.";
    }

    // Validate email address
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Enter a valid email address.";
    }

    if (!empty($errors)) {
        echo json_encode(['success' => false, 'errors' => $errors]);
        exit;
    }

    try {
        // Create a PHPMailer instance
        $mail = new PHPMailer(true);

        // Server settings
        $mail->isSMTP();                                      // Use SMTP
        $mail->Host = 'smtp.hostinger.com';                     // Set SMTP server
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'noreaply@stayease.in';                 // SMTP username
        $mail->Password = 'Veeranji123@';                           // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;      // Enable TLS encryption
        $mail->Port = 465;                                    // TCP port for SSL

        // -----------------------
        // Email to the Client
        // -----------------------
        $mail->setFrom('noreaply@stayease.in', 'stayease'); // Sender
        $mail->addAddress($email, $name);                     // Recipient

        // Client email content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Thank You for Contacting Us';
        $mail->Body = "
        <!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Thank You for Subscribing</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333333;
        }
        .email-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
            background-color: #4CAF50;
            color: #ffffff;
            padding: 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }
        .content {
            padding: 20px;
        }
        .content h2 {
            font-size: 22px;
            color: #333333;
            margin-bottom: 15px;
        }
        .content p {
            font-size: 16px;
            color: #555555;
            line-height: 1.6;
            margin-bottom: 15px;
        }
        .content ul {
            padding: 0;
            list-style: none;
            margin: 0 0 20px 0;
        }
        .content ul li {
            font-size: 16px;
            color: #333333;
            margin: 5px 0;
        }
        .content ul li strong {
            color: #555555;
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }
        .button {
            display: inline-block;
            padding: 12px 25px;
            font-size: 16px;
            font-weight: bold;
            color: #ffffff;
            background-color: #4CAF50;
            text-decoration: none;
            border-radius: 5px;
        }
        .footer {
            background-color: #f9f9f9;
            text-align: center;
            padding: 15px;
            font-size: 14px;
            color: #777777;
            border-top: 1px solid #dddddd;
        }
        .footer p {
            margin: 0;
        }
        @media (max-width: 600px) {
            .content h2 {
                font-size: 20px;
            }
            .button {
                padding: 10px 20px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class='email-container'>
        <div class='header'>
            <h1>Thank You for Contacting Us!</h1>
        </div>
        <div class='content'>
            <h2>Hello, $name</h2>
            <p>Thank you for reaching out to us. We have received your submission and will get back to you shortly.</p>
                        <p><strong>Your Details:</strong></p>
                        <ul>
                            <li><strong>Name:</strong> $name</li>
                            <li><strong>Mobile:</strong> $mobile</li>
                            <li><strong>Email:</strong> $email</li>
                        </ul>
            <p>This is an automated notification. Please do not reply to this email.</p>
            <div class='button-container'>
                <a href='https://stayease.in' class='button'>Visit Our Website</a>
            </div>
        </div>
        <div class='footer'>
            <p>&copy; 2024 stayease. All Rights Reserved.</p>
        </div>
    </div>
</body>
</html>
";
        $mail->AltBody = "Thank you for contacting us, $name. We have received your submission.";

        // Send email to the client
        $mail->send();

        // -----------------------
        // Email to the Admin
        // -----------------------
        $mail->clearAddresses();                              // Clear previous recipient
        $mail->addAddress('koyaveeranjaneyulu348@gmail.com');               // Admin email

        // Admin email content
        $mail->Subject = 'New Submission Received';
        $mail->Body = "
        <!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Thank You for Subscribing</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333333;
        }
        .email-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header {
            background-color: #4CAF50;
            color: #ffffff;
            padding: 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }
        .content {
            padding: 20px;
        }
        .content h2 {
            font-size: 22px;
            color: #333333;
            margin-bottom: 15px;
        }
        .content p {
            font-size: 16px;
            color: #555555;
            line-height: 1.6;
            margin-bottom: 15px;
        }
        .content ul {
            padding: 0;
            list-style: none;
            margin: 0 0 20px 0;
        }
        .content ul li {
            font-size: 16px;
            color: #333333;
            margin: 5px 0;
        }
        .content ul li strong {
            color: #555555;
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }
        .button {
            display: inline-block;
            padding: 12px 25px;
            font-size: 16px;
            font-weight: bold;
            color: #ffffff;
            background-color: #4CAF50;
            text-decoration: none;
            border-radius: 5px;
        }
        .footer {
            background-color: #f9f9f9;
            text-align: center;
            padding: 15px;
            font-size: 14px;
            color: #777777;
            border-top: 1px solid #dddddd;
        }
        .footer p {
            margin: 0;
        }
        @media (max-width: 600px) {
            .content h2 {
                font-size: 20px;
            }
            .button {
                padding: 10px 20px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class='email-container'>
        <div class='header'>
            <h1>Thank You for Subscribing!</h1>
        </div>
        <div class='content'>
            <h2>Hello, Koya Veeranjaneyulu</h2>
            <p><strong>Details of the Submission:</strong></p>
            <ul>
                <li><strong>Name:</strong> $name</li>
                <li><strong>Mobile:</strong> $mobile</li>
                <li><strong>Email:</strong> $email</li>
            </ul>
            <p>This is an automated notification. Please do not reply to this email.</p>
            <div class='button-container'>
                <a href='https://stayease.in' class='button'>Visit Our Website</a>
            </div>
        </div>
        <div class='footer'>
            <p>&copy; 2024 stayease. All Rights Reserved.</p>
        </div>
    </div>
</body>
</html>

";
        $mail->AltBody = "New submission received: Name: $name, Mobile: $mobile, Email: $email";

        // Send email to the admin
        $mail->send();

        echo json_encode(['success' => true, 'message' => 'Your form has been successfully submitted.']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => "Mailer Error: {$mail->ErrorInfo}"]);
    }
}
